// $("form").submit(function() { //Change
// 		var th = $(this);
// 		$.ajax({
// 			type: "POST",
// 			url: "mail.php", //Change
// 			data: th.serialize()
// 		}).done(function() {
// 			setTimeout(function() {
// 				// Done Functions
// 				th.trigger("reset");
// 			}, 500);
// 		});
// 		return false;
// 	});